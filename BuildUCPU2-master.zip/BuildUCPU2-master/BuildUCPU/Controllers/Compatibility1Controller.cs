﻿using Microsoft.AspNetCore.Mvc;

namespace BuildUCPU.Controllers
{
    public class Compatibility1Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
