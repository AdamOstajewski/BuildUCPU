﻿using Microsoft.AspNetCore.Mvc;

namespace BuildUCPU.Controllers.Footer
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
