﻿using Microsoft.AspNetCore.Mvc;

namespace BuildUCPU.Controllers.Footer
{
    public class PrivacyPolicyController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
